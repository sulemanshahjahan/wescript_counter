<?php

$name = $_POST['name'];
$email = $_POST['email'];
$number = $_POST['number'];
$message = $_POST['message'];


$to = 'suleman.shahjahan@gmail.com';
$subject = 'Contact Wescript';
$body = "Name: $name \nEmail: $email \nNumber: $number \nMessage: $message";


if(mail($to,$subject,$body)){
	header("Location: thank-you.html");
}

?>